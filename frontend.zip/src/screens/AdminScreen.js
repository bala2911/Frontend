import React from 'react';

const AdminScreen = () => {
  <div>AdminScreen</div>;
};

export default AdminScreen;
